#include <stdio.h>
#include <string.h>

#define N 2000005
#define MOD 1000000007

int n, sum[N];
long long hsh[N], pw[N] = {1};
char s[N];
struct pair {
    int first;
    int second;
};
struct pair ans = {N, N};

struct deque {
    int arr[N];
    int front;
    int rear;
};

void init(struct deque *de) {
    de->front = -1;
    de->rear = -1;
}

int isEmpty(struct deque *de) {
    if (de->front == -1) {
        return 1;
    } else {
        return 0;
    }
}

int isFull(struct deque *de) {
    if ((de->front == 0 && de->rear == N - 1) || (de->front == de->rear + 1)) {
        return 1;
    } else {
        return 0;
    }
}

void push_back(struct deque *de, int x) {
    if (isFull(de)) {
        return;
    } else if (de->front == -1) {
        de->front = 0;
        de->rear = 0;
    } else if (de->rear == N - 1) {
        de->rear = 0;
    } else {
        de->rear++;
    }
    de->arr[de->rear] = x;
}

void push_front(struct deque *de, int x) {
    if (isFull(de)) {
        return;
    } else if (de->front == -1) {
        de->front = 0;
        de->rear = 0;
    } else if (de->front == 0) {
        de->front = N - 1;
    } else {
        de->front--;
    }
    de->arr[de->front] = x;
}

void pop_back(struct deque *de) {
    if (isEmpty(de)) {
        return;
    } else if (de->front == de->rear) {
        de->front = -1;
        de->rear = -1;
    } else if (de->rear == 0) {
        de->rear = N - 1;
    } else {
        de->rear--;
    }
}

void pop_front(struct deque *de) {
    if (isEmpty(de)) {
        return;
    } else if (de->front == de->rear) {
        de->front = -1;
        de->rear = -1;
    } else if (de->front == N - 1) {
        de->front = 0;
    } else {
        de->front++;
    }
}

int front(struct deque *de) {
    if (isEmpty(de)) {
        return -1;
    } else {
        return de->arr[de->front];
    }
}

int back(struct deque *de) {
    if (isEmpty(de)) {
        return -1;
    } else {
        return de->arr[de->rear];
    }
}

long long get_hash(int l, int r) {
    return (hsh[r] - hsh[l - 1] * pw[r - l + 1] + 1LL * MOD * MOD) % MOD;
}

int compare(int u, int v) {
    int le = 0, ri = n - 1;
    while (le <= ri) {
        int mi = (le + ri) / 2;
        if (get_hash(u, u + mi) == get_hash(v, v + mi)) {
            le = mi + 1;
        } else {
            ri = mi - 1;
        }
    }
    if (le == n) {
        return 1;
    } else {
        return s[u + le] < s[v + le];
    }
}

int main() {
    scanf("%s", s);
    n = strlen(s);
    for (int i = 0; i < n; i++) {
        s[i + n] = s[i];
        sum[i + n] = sum[i] = (s[i] == 'A' ? 1 : -1);
        hsh[i + n] = hsh[i] = (s[i] == 'A' ? 0 : 1);
    }
    for (int i = 1; i < 2 * n; i++) {
        sum[i] += sum[i - 1];
        pw[i] = pw[i - 1] * 2 % MOD;
        hsh[i] = (hsh[i]+ hsh[i - 1] * 2) % MOD;
    }
    struct deque de;
    init(&de);
    for (int i = 0; i < n; i++) {
        while (!isEmpty(&de) && sum[back(&de)] >= sum[i]) {
            pop_back(&de);
        }
        push_back(&de, i);
    }
    for (int i = n; i < 2 * n; i++) {
        int u = i - n + 1;
        while (!isEmpty(&de) && sum[back(&de)] >= sum[i]) {
            pop_back(&de);
        }
        push_back(&de, i);
        while (!isEmpty(&de) && front(&de) < i - n) {
            pop_front(&de);
        }
        int len = sum[i - n] - sum[front(&de)];
        if (len < ans.first) {
            ans.first = len;
            ans.second = u;
        } else if (len == ans.first && compare(u, ans.second)) {
            ans.first = len;
            ans.second = u;
        }
    }
    for (int i = 0; i < ans.first; i++) {
        printf("A");
    }
    for (int i = 0; i < n; i++) {
        printf("%c", s[ans.second % n + i]);
    }
    for (int i = 0; i < ans.first + sum[n - 1]; i++) {
        printf("B");
    }
    return 0;
}
