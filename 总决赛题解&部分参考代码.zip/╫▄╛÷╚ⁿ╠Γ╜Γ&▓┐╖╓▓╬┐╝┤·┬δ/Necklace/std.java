import java.util.Arrays;
import java.util.Scanner;

public class std {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String c = scanner.next();
        int n = c.length();
        int t = 0;
        for (int i = 0; i < n; i++) {
            t += (c.charAt(i) == 'A') ? 1 : -1;
            // System.out.print((c.charAt(i) == 'A') ? 1 : -1);
        }
        char[] c2 = new char[2 * n];
        for (int i = 0; i < n; i++) {
            c2[i] = c.charAt(i);
        }
        for (int i = n; i < 2 * n; i++) {
            c2[i] = c.charAt(i - n);
        }
        if (t < 0) {
            for (int i = 0; i < -t; i++) {
                System.out.print("A");
            }
        }
        int[] h = new int[2000005];
        for(int i = 0;i < 2000000;i ++){
            h[i] = 0;
        }
        for (int i = 1; i <= 2 * n; i++) {
            h[i] = h[i - 1] + ((c2[i - 1] == 'A') ? 1 : -1);
        }
        int H = 1;
        int T = 0;
        int[] q = new int[2000005];
        for(int i = 0;i < 2000000;i ++){
            q[i] = 0;
        }
        for (int i = 1; i <= n; i++) {
            while (T > 0 && h[i] < h[q[T]]) {
                T--;
            }
            q[++T] = i;
        }
        boolean[] b = new boolean[2000005];
        for(int i = 0;i < 2000005;i ++){
            b[i] = false;
        }
        for (int i = 1; i <= n; i++) {
            if (h[q[H]] - h[i - 1] < Math.min(t, 0)) {
                b[i] = true;
            }
            b[n+1] = false;
            while (T >= H && h[n + i] < h[q[T]]) {
                T--;
            }
            q[++T] = n + i;
            if (q[H] == i) {
                H++;
            }
        }
        int i = 1;
        int j = 2;
        while (true) {
            while (b[i]) {
                i++;
            }
            while (b[j]) {
                j++;
            }
            if (i == j) {
                j++;
                while (b[j]) {
                    j++;
                }
            }
            if (i > n || j > n) {
                break;
            }
            int k = 0;
            while (k < n && c2[i + k - 1] == c2[j + k - 1]) {
                k++;
            }
            if (c2[i + k - 1] < c2[j + k - 1]) {
                j = j + k + 1;
            } else {
                i = i + k + 1;
            }
        }
        if (j < i) {
            i = j;
        }
        for (int k = i; k < n + i; k++) {
            System.out.print(c2[k - 1]);
        }
        if (t > 0) {
            for (int k = 0; k < t; k++) {
                System.out.print("B");
            }
        }
    }
}
