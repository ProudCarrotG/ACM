#include<bits/stdc++.h>
using namespace std;
#define ull long long
const ull mod=1e9+7;
char s[2000005];
int sum[2000005];
int st[2000005][23];
int lg2[2000005];
int n;
ull has[2000005],pow3[2000005];
int query(int l,int r){
	int k=lg2[r-l];
	return min(st[l][k],st[r-(1<<k)+1][k]);
}
ull gethash(int l,int r){
	return (has[r]-has[l-1]*pow3[r-l+1]%mod+mod)%mod;
}
bool check(int i,int j){
	int l=0,r=n;
	while(l<r){
		int mid=l+r>>1;
		if(gethash(i,i+mid-1)!=gethash(j,j+mid-1))r=mid;
		else l=mid+1;
	}
	if(s[i+l-1]<s[j+l-1])return 1;
	else return 0;
}
int main(){
	scanf("%s",s);n=strlen(s);
	for(int i=2;i<=2*n;i++)lg2[i]=lg2[i/2]+1;
	for(int i=0;i<n;i++)s[i+n]=s[i];
	sum[0]=(s[0]=='A'?1:-1);has[0]=(s[0]=='A'?1:2);pow3[0]=1;
	for(int i=1;i<n*2;i++)sum[i]=sum[i-1]+(s[i]=='A'?1:-1),has[i]=(has[i-1]*5+(s[i]=='A'?1:2))%mod,pow3[i]=pow3[i-1]*5%mod;
	for(int i=0;i<n*2;i++)st[i][0]=sum[i];
	for(int j=1;j<=20;j++)
		for(int i=0;i<=n*2-(1<<j);i++)st[i][j]=min(st[i][j-1],st[i+(1<<j-1)][j-1]);
	int add=sum[n-1];
	if(add>0){
		int mxpos=-1;
		for(int i=0;i<n;i++)
			if(query(i,i+n-1)>=(i==0?0:sum[i-1]))
				if(mxpos<0||check(i,mxpos))mxpos=i;
		for(int i=mxpos;i<mxpos+n;i++)putchar(s[i]);
		while(add--)putchar('B');
		// puts("");
	}else{
		int mxpos=-1;
		for(int i=0;i<n;i++)
			if(query(i,i+n-1)>=add+(i==0?0:sum[i-1]))
				if(mxpos<0||check(i,mxpos))mxpos=i;
		add=-add;
		while(add--)putchar('A');
		for(int i=mxpos;i<mxpos+n;i++)putchar(s[i]);
		// puts("");
	}
	return 0;
}