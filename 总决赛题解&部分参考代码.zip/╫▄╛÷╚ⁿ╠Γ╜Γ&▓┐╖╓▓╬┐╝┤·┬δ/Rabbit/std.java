import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Main {
    public static int[] a = new int[2001];
    public static int[] b = new int[2001];
    public static int[] c = new int[2001];
    public static int[][] dp = new int[2001][2001];


    public static void main(String[] args) {
        //Scanner scanner = new Scanner(System.in);
        Scanner scanner = new Scanner(System.in);
        
        int n, x;
        n = scanner.nextInt();
        x = scanner.nextInt();
        for (int i = 1; i <= n; i++) {
            a[i] = scanner.nextInt();
            b[i] = scanner.nextInt();
            c[i] = scanner.nextInt();
        }
        for (int i = 0; i <= 2000; i++)
            for (int j = 0; j <= 2000; j++) dp[i][j] = -1000000000;
        dp[0][0] = 0;
        for (int i = 1; i <= n; i++) {
            for (int j = 0; j <= 2000; j++) {
                dp[i][Math.min(2000, j + a[i])] = Math.max(dp[i][Math.min(2000, j + a[i])], dp[i - 1][j] + a[i]);
                dp[i][j] = Math.max(dp[i][j], dp[i - 1][j] + b[i] + Math.min(b[i] * 2, c[i]));
                dp[i][j] = Math.max(dp[i][j], dp[i - 1][j] + c[i]);
            }
        }
        int ans = -1;
        for (int i = x; i <= 2000; i++)
            ans = Math.max(ans, dp[n][i]);
        System.out.println(ans);
    }
}
