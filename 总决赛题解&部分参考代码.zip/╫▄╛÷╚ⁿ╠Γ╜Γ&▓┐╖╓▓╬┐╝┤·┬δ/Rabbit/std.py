n, x = map(int, input().split())
a = [0] * 2001
b = [0] * 2001
c = [0] * 2001
dp = [[-1000000000] * 2001 for _ in range(2001)]

for i in range(1, n + 1):
    a[i], b[i], c[i] = map(int, input().split())

dp[0][0] = 0

for i in range(1, n + 1):
    for j in range(2001):
        dp[i][min(2000, j + a[i])] = max(dp[i][min(2000, j + a[i])], dp[i - 1][j] + a[i])
        dp[i][j] = max(dp[i][j], dp[i - 1][j] + b[i] + min(b[i] * 2, c[i]))
        dp[i][j] = max(dp[i][j], dp[i - 1][j] + c[i])

ans = -1
for i in range(x, 2001):
    ans = max(ans, dp[n][i])

print(ans)
