﻿#include<bits/stdc++.h>
using namespace std;
int a[2001],b[2001],c[2001];
int dp[2001][2001];
int main() {
    int n,x;
    cin>>n>>x;
  
    for(int i=1;i<=n;i++) 
        cin>>a[i]>>b[i]>>c[i];
    
    for(int i=0;i<=2000;i++)
        for(int j=0;j<=2000;j++) dp[i][j]=-1000000000;
    dp[0][0]=0;
    for(int i=1;i<=n;i++) {
        //之前吃了j个白巧克力
        for(int j=0;j<=2000;j++) {
            //Case1: 吃白巧克力
            dp[i][min(2000,j+a[i])] = max(dp[i][min(2000,j+a[i])],dp[i-1][j]+a[i]);
            //Case2：吃灰巧克力+黑巧克力
            dp[i][j] = max(dp[i][j],dp[i-1][j]+b[i]+min(b[i]*2,c[i]));
            //Case3：吃黑巧克力
            dp[i][j] = max(dp[i][j],dp[i-1][j]+c[i]);
        }
    }
    int ans = -1;
    for(int i=x;i<=2000;i++)
        ans = max(ans, dp[n][i]);
    cout<<ans<<endl;
}
