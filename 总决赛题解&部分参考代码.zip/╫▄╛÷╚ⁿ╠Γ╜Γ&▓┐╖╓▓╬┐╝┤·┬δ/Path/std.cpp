#include<bits/stdc++.h>
using namespace std ;
const int maxn = 1e5 + 10 ;
const int inf = 1e9 ;
int n , k ;
int a[maxn] ;
vector<int> g[maxn] ;
int siz[maxn] ;
int maxp[maxn] ;
int vis[maxn] ;
int root = 0 ;
int sum = 0 ;
int cur = 0 ;
int t[maxn] ;
long long c[maxn] ;
long long res = 0 ;
void get_root(int fa , int u) //求重心 
{
	siz[u] = 1 , maxp[u] = 0 ;
	for(auto v : g[u])
	{
		if(v == fa || vis[v] == 1)  continue ;
		get_root(u , v) ; //先递归得到子树大小
		siz[u] += siz[v] ;
		maxp[u] = max(maxp[u] , siz[v]) ; //更新u结点的maxp
	}
	maxp[u] = max(maxp[u] , sum - siz[u]) ;
	if(maxp[u] < maxp[root]) root = u ; //更新当前子树的重心
}
void dfs0(int fa , int u , int dep , long long sum , int mx)
{
    if(dep > k)  return ;
    if(t[k - dep] == cur)  res = max(res , c[k - dep] + sum + mx) ;
    if(dep == k)  res = max(res , sum + mx) ;
    for(auto v : g[u])
    {
        if(v == fa || vis[v] == 1)  continue ;
        dfs0(u , v , dep + 1 , sum + a[v] , max(mx , a[v])) ;
    }
}
void dfs(int fa , int u , int dep , long long sum)
{
    if(dep >= k - 1)  return ;
    if(t[dep] != cur)  c[dep] = sum , t[dep] = cur ;
    else  c[dep] = max(c[dep] , sum) ;
    for(auto v : g[u])
    {
        if(v == fa || vis[v] == 1)  continue ;
        dfs(u , v , dep + 1 , sum + a[v]) ;
    }
}
void solve(int u)
{	
    cur += 1 ;
    for(auto v : g[u])
    {
        if(vis[v] == 1)  continue ;
        dfs0(u , v , 2 , a[u] + a[v] , max(a[u] , a[v])) ;
        dfs(u , v , 1 , a[v]) ;
    }
	vis[u] = 1 ; //删除p节点
    for(auto v : g[u])
	{
		if(vis[v] == 1)  continue ;
		root = 0 , maxp[0] = inf , sum = siz[v] ; //初始化 
		get_root(0 , v) ;
		solve(root) ;	
	}
}
int main() 
{
    std::ios::sync_with_stdio(false) , cin.tie(0) ;
    
    cin >> n >> k ;
    for(int i = 1 ; i <= n ; i ++)  cin >> a[i] ;
    for(int i = 1 ; i <= n - 1 ; i ++)
    {
        int u , v ;
        cin >> u >> v ;
        g[u].push_back(v) ;
        g[v].push_back(u) ;
    }
    if(k == 1)
    {
        cout << 2 * (*max_element(a + 1 , a + n + 1)) << '\n' ;
        return 0 ;
    }
    root = 0 , maxp[0] = inf , sum = n ;
    get_root(0 , 1) ;
    solve(root) ;
    for(int i = 1 ; i <= n ; i ++)  reverse(g[i].begin() , g[i].end()) ;
    memset(vis , 0 , sizeof(vis)) ;
    root = 0 , maxp[0] = inf , sum = n ;
    get_root(0 , 1) ;
    solve(root) ;
    cout << res << '\n' ;

    return 0 ;
}