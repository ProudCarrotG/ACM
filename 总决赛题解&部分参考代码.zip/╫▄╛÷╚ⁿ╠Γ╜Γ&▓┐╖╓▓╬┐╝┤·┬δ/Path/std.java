import java.util.*;

public class Main {
    static final int MAXN = 100010;
    static final int INF = 1000000000;
    static int n, k;
    static int[] a = new int[MAXN];
    static int[] siz = new int[MAXN];
    static int[] maxp = new int[MAXN];
    static int[] vis = new int[MAXN];
    static int root = 0;
    static int sum = 0;
    static int cur = 0;
    static int[] t = new int[MAXN];
    static long[] c = new long[MAXN];
    static long res = 0;
    static Edge[] edge = new Edge[MAXN << 1];
    static int num = 0;
    static int[] head = new int[MAXN];

    static class Edge {
        int v, next;

        public Edge(int v, int next) {
            this.v = v;
            this.next = next;
        }
    }

    static void init() {
        num = 0;
        Arrays.fill(head, -1);
    }

    static void addEdge(int u, int v) {
        num++;
        edge[num] = new Edge(v, head[u]);
        head[u] = num;
    }

    static int[] uu = new int[MAXN], vv = new int[MAXN];

    static void getRoot(int fa, int u) { // 求重心
        siz[u] = 1;
        maxp[u] = 0;
        for (int i = head[u]; i != -1; i = edge[i].next) {
            int v = edge[i].v;
            if (v == fa || vis[v] == 1) continue;
            getRoot(u, v); // 先递归得到子树大小
            siz[u] += siz[v];
            if (siz[v] > maxp[u]) maxp[u] = siz[v];
        }
        if (sum - siz[u] > maxp[u]) maxp[u] = sum - siz[u];
        if (maxp[u] < maxp[root]) root = u; // 更新当前子树的重心
    }

    static void dfs0(int fa, int u, int dep, long sum, int mx) {
        if (dep > k)
            return;
        if (t[k - dep] == cur && c[k - dep] + sum + mx > res)
            res = c[k - dep] + sum + mx;
        if (dep == k && sum + mx > res)
            res = sum + mx;
        for (int i = head[u]; i != -1; i = edge[i].next) {
            int v = edge[i].v;
            if (v == fa || vis[v] == 1) continue;
            int z = mx;
            if (a[v] > z)
                z = a[v];
            dfs0(u, v, dep + 1, sum + a[v], z);
        }
    }

    static void dfs(int fa, int u, int dep, long sum) {
        if (dep >= k - 1)
            return;
        if (t[dep] != cur)
            c[dep] = sum;
        else if (sum > c[dep])
            c[dep] = sum;
        t[dep] = cur;
        for (int i = head[u]; i != -1; i = edge[i].next) {
            int v = edge[i].v;
            if (v == fa || vis[v] == 1) continue;
            dfs(u, v, dep + 1, sum + a[v]);
        }
    }

    static void solve(int u) {
        cur += 1;
        for (int i = head[u]; i != -1; i = edge[i].next) {
            int v = edge[i].v;
            if (vis[v] == 1) continue;
            int z = a[u];
            if (a[v] > z)
                z = a[v];
            dfs0(u, v, 2, a[u] + a[v], z);
            dfs(u, v, 1, a[v]);
        }
        vis[u] = 1; // 删除p节点
        for (int i = head[u]; i != -1; i = edge[i].next) {
            int v = edge[i].v;
            if (vis[v] == 1) continue;
            root = 0;
            maxp[0] = INF;
            sum = siz[v];

            // 初始化
            getRoot(0, v);
            solve(root);
        }
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        n = sc.nextInt();
        k = sc.nextInt();
        for (int i = 1; i <= n; i++)
            a[i] = sc.nextInt();
        init();
        for (int i = 1; i <= n - 1; i++) {
            int u = sc.nextInt();
            int v = sc.nextInt();
            uu[i] = u;
            vv[i] = v;
            addEdge(u, v);
            addEdge(v, u);
        }
        if (k == 1) {
            int mx = 0;
            for (int i = 1; i <= n; i++)
                if (a[i] > mx)
                    mx = a[i];
            System.out.println(mx * 2);
            return;
        }
        root = 0;
        maxp[0] = INF;
        sum = n;
        getRoot(0, 1);
        solve(root);
        init();
        for (int i = n - 1; i >= 1; i--)
            addEdge(uu[i], vv[i]);
        Arrays.fill(vis, 0);
        root = 0;
        maxp[0] = INF;
        sum = n;
        getRoot(0, 1);
        solve(root);
        System.out.println(res);
    }
}