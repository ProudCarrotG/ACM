#include <stdio.h>
#include <stdlib.h>
#include <string.h>
const int maxn = 1e5 + 10 ;
const int inf = 1e9 ;
int n , k ;
int a[200000] ;
int siz[200000] ;
int maxp[200000] ;
int vis[200000] ;
int root = 0 ;
int sum = 0 ;
int cur = 0 ;
int t[200000] ;
long long c[200000] ;
long long res = 0 ;
struct Edge
{
    int v , next ;
} edge[200000 << 1] ;
int num , head[200000] ;
void init()
{
    num = 0 ;
    for(int i = 1 ; i <= 200000 ; i ++)  head[i] = -1 ;
}
void add_edge(int u , int v)
{
    num ++ ;
    edge[num].v = v ;
    edge[num].next = head[u] ;
    head[u] = num ;	
} 
int uu[200000] , vv[200000] ;
void get_root(int fa , int u) //求重心 
{
	siz[u] = 1 , maxp[u] = 0 ;
    for(int i = head[u] ; i != -1 ; i = edge[u].next)
	{
        int v = edge[i].v ;
		if(v == fa || vis[v] == 1)  continue ;
		get_root(u , v) ; //先递归得到子树大小
		siz[u] += siz[v] ;
        if(siz[v] > maxp[u])  maxp[u] = siz[v] ;
	}
    if(sum - siz[u] > maxp[u])  maxp[u] = sum - siz[u] ;
	if(maxp[u] < maxp[root]) root = u ; //更新当前子树的重心
}
void dfs0(int fa , int u , int dep , long long sum , int mx)
{
    if(dep > k)  return ;
    if(t[k - dep] == cur && c[k - dep] + sum + mx > res)  res = c[k - dep] + sum + mx ;
    if(dep == k && sum + mx > res)  res = sum + mx ;
    for(int i = head[u] ; i != -1 ; i = edge[u].next)
	{
        int v = edge[i].v ;
        if(v == fa || vis[v] == 1)  continue ;
        int z = mx ;
        if(a[v] > z)  z = a[v] ;
        dfs0(u , v , dep + 1 , sum + a[v] , z) ;
    }
}
void dfs(int fa , int u , int dep , long long sum)
{
    if(dep >= k - 1)  return ;
    if(t[dep] != cur)  c[dep] = sum , t[dep] = cur ;
    else if(sum > c[dep])  c[dep] = sum ;
    for(int i = head[u] ; i != -1 ; i = edge[u].next)
	{
        int v = edge[i].v ;
        if(v == fa || vis[v] == 1)  continue ;
        dfs(u , v , dep + 1 , sum + a[v]) ;
    }
}
void solve(int u)
{	
    cur += 1 ;
    for(int i = head[u] ; i != -1 ; i = edge[u].next)
	{
        int v = edge[i].v ;
        if(vis[v] == 1)  continue ;
        int z = a[u] ;
        if(a[v] > z)  z = a[v] ;
        dfs0(u , v , 2 , a[u] + a[v] , z) ;
        dfs(u , v , 1 , a[v]) ;
    }
	vis[u] = 1 ; //删除p节点
    for(int i = head[u] ; i != -1 ; i = edge[u].next)
	{
        int v = edge[i].v ;
		if(vis[v] == 1)  continue ;
		root = 0 , maxp[0] = inf , sum = siz[v] ; //初始化 
		get_root(0 , v) ;
		solve(root) ;	
	}
}
int main() 
{
    scanf("%d%d" , &n , &k) ;
    for(int i = 1 ; i <= n ; i ++)  scanf("%d" , &a[i]) ;
    init() ;
    for(int i = 1 ; i <= n - 1 ; i ++)
    {
        int u , v ;
        scanf("%d%d" , &u , &v) ;
        uu[i] = u ;
        vv[i] = v ;
        add_edge(u , v) ;
        add_edge(v , u) ;
    }
    if(k == 1)
    {
        int mx = 0 ;
        for(int i = 1 ; i <= n ; i ++)  
            if(a[i] > mx)
                mx = a[i] ;
        printf("%d\n" , mx * 2) ;
        return 0 ;
    }
    root = 0 , maxp[0] = inf , sum = n ;
    get_root(0 , 1) ;
    solve(root) ;
    init() ;
    for(int i = n - 1 ; i >= 1 ; i --)  add_edge(uu[i] , vv[i]) ;
    memset(vis , 0 , sizeof(vis)) ;
    root = 0 , maxp[0] = inf , sum = n ;
    get_root(0 , 1) ;
    solve(root) ;
    printf("%lld\n" , res) ;

    return 0 ;
}