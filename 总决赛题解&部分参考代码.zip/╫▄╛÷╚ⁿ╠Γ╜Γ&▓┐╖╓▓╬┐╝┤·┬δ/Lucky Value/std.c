#include <stdio.h>

#define N 100005

int n,l=0,cnt=0;
long long sum=0;
int a[N],b[N],h[N<<1],to[N<<1],s[N],size[N],son[N],vis[N],mx[N];
long long Ans[N];

void hah(int x,int y){
    to[++l]=y,h[l]=s[x],s[x]=l;
    to[++l]=x,h[l]=s[y],s[y]=l;
}
void get_son(int x,int Fa){
    size[x]=1;
    int i;
    for(i=s[x];i;i=h[i]){
        if(to[i]!=Fa){
            get_son(to[i],x);
            size[x]+=size[to[i]];
            if(size[to[i]]>size[son[x]])son[x]=to[i];
        }
    }
}
void check(int x,int Fa){
    vis[a[x]]=0;
    mx[a[x]]=0;
    int i;
    for(i=s[x];i;i=h[i]){
        if(to[i]!=Fa){
            check(to[i],x);
        }
    }
}
int Max(int x,int y){
	return x>y?x:y;
}
void dfs2(int x,int Fa,int p){
	int i;
    vis[a[x]]++;
    mx[a[x]]=Max(mx[a[x]],b[x]);
    if(vis[a[x]]>cnt){
        cnt=vis[a[x]];
        sum=1ll*mx[a[x]];
    }
    else if(vis[a[x]]==cnt)sum+=1ll*mx[a[x]];
    for(i=s[x];i;i=h[i]){
        if(to[i]!=Fa && to[i]!=p)dfs2(to[i],x,p);
    }
}
void dfs(int x,int Fa){
	int i;
    for(i=s[x];i;i=h[i]){
        if(to[i]!=Fa && to[i]!=son[x]){
            dfs(to[i],x);
            check(to[i],x);
            sum=cnt=0;
        }
    }
    if(son[x])dfs(son[x],x);
    dfs2(x,Fa,son[x]);
    Ans[x]=sum;
}
int main(){
    //freopen("20.in","r",stdin);
    //freopen("20.out","w",stdout);
    int i;
    scanf("%d",&n);
    for(i=1;i<=n;i++)scanf("%d",&a[i]);
    for(i=1;i<=n;i++)scanf("%d",&b[i]);
    for(i=1;i<n;i++){
        int x,y;
        scanf("%d%d",&x,&y);
        hah(x,y);
    }
    get_son(1,0);
    dfs(1,0);
    for(i=1;i<=n;i++)printf("%lld\n",Ans[i]);
}
/*
4
1 2 3 4
2 3 4 5
1 2
2 3
2 4
*/

