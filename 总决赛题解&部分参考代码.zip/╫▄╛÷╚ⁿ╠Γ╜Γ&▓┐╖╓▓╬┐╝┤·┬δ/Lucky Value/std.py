N = 100005

n = 0
l = 0
cnt = 0
sum = 0
a = [0] * N
b = [0] * N
h = [0] * (N << 1)
to = [0] * (N << 1)
s = [0] * N
size = [0] * N
son = [0] * N
vis = [0] * N
mx = [0] * N
Ans = [0] * N

def hah(x, y):
    global l
    to[l + 1] = y
    h[l + 1] = s[x]
    s[x] = l + 1
    to[l + 2] = x
    h[l + 2] = s[y]
    s[y] = l + 2
    l += 2

def get_son(x, Fa):
    global size, son
    size[x] = 1
    for i in range(s[x]):
        if to[i] != Fa:
            get_son(to[i], x)
            size[x] += size[to[i]]
            if size[to[i]] > size[son[x]]:
                son[x] = to[i]

def check(x, Fa):
    global vis, mx
    vis[a[x]] = 0
    mx[a[x]] = 0
    for i in range(s[x]):
        if to[i] != Fa:
            check(to[i], x)

def dfs2(x, Fa, p):
    global vis, cnt, sum
    vis[a[x]] += 1
    mx[a[x]] = max(mx[a[x]], b[x])
    if vis[a[x]] > cnt:
        cnt = vis[a[x]]
        sum = 1ll * mx[a[x]]
    elif vis[a[x]] == cnt:
        sum += 1ll * mx[a[x]]
    for i in range(s[x]):
        if to[i] != Fa and to[i] != p:
            dfs2(to[i], x, p)

def dfs(x, Fa):
    global s, son, cnt, sum
    for i in range(s[x]):
        if to[i] != Fa and to[i] != son[x]:
            dfs(to[i], x)
            check(to[i], x)
            sum = cnt = 0
    if son[x]:
        dfs(son[x], x)
    dfs2(x, Fa, son[x])
    Ans[x] = sum

def main():
    global n
    # sys.stdin = open('20.in', 'r')
    # sys.stdout = open('20.out', 'w')
    n = int(input())
    a[1:n + 1] = map(int, input().split())
    b[1:n + 1] = map(int, input().split())
    for i in range(n - 1):
        x, y = map(int, input().split())
        hah(x, y)
    get_son(1, 0)
    dfs(1, 0)
    for i in range(1, n + 1):
        print(Ans[i])

if __name__ == '__main__':
    main()
