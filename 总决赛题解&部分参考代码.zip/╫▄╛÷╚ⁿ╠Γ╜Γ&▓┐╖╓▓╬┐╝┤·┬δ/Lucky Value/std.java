import java.util.*;

public class Main {

    static final int N = 100005;

    static int n, l = 0, cnt = 0;
    static long sum = 0;
    static int[] a = new int[N];
    static int[] b = new int[N];
    static int[] h = new int[N << 1];
    static int[] to = new int[N << 1];
    static int[] s = new int[N];
    static int[] size = new int[N];
    static int[] son = new int[N];
    static int[] vis = new int[N];
    static int[] mx = new int[N];
    static long[] Ans = new long[N];

    public static void hah(int x, int y) {
        to[++l] = y;
        h[l] = s[x];
        s[x] = l;
        to[++l] = x;
        h[l] = s[y];
        s[y] = l;
    }

    public static void get_son(int x, int Fa) {
        size[x] = 1;
        for (int i = s[x]; i != 0; i = h[i]) {
            if (to[i] != Fa) {
                get_son(to[i], x);
                size[x] += size[to[i]];
                if (size[to[i]] > size[son[x]]) {
                    son[x] = to[i];
                }
            }
        }
    }

    public static void check(int x, int Fa) {
        vis[a[x]] = 0;
        mx[a[x]] = 0;
        for (int i = s[x]; i != 0; i = h[i]) {
            if (to[i] != Fa) {
                check(to[i], x);
            }
        }
    }

    public static void dfs2(int x, int Fa, int p) {
        vis[a[x]]++;
        mx[a[x]] = Math.max(mx[a[x]], b[x]);
        if (vis[a[x]] > cnt) {
            cnt = vis[a[x]];
            sum = 1L * mx[a[x]];
        } else if (vis[a[x]] == cnt) {
            sum += 1L * mx[a[x]];
        }
        for (int i = s[x]; i != 0; i = h[i]) {
            if (to[i] != Fa && to[i] != p) {
                dfs2(to[i], x, p);
            }
        }
    }

    public static void dfs(int x, int Fa) {
        for (int i = s[x]; i != 0; i = h[i]) {
            if (to[i] != Fa && to[i] != son[x]) {
                dfs(to[i], x);
                check(to[i], x);
                sum = cnt = 0;
            }
        }
        if (son[x] != 0) {
            dfs(son[x], x);
        }
        dfs2(x, Fa, son[x]);
        Ans[x] = sum;
    }

    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        n = in.nextInt();
        for (int i = 1; i <= n; i++) {
            a[i] = in.nextInt();
        }
        for (int i = 1; i <= n; i++) {
            b[i] = in.nextInt();
        }
        for (int i = 1; i < n; i++) {
            int x = in.nextInt();
            int y = in.nextInt();
            hah(x, y);
        }
        get_son(1, 0);
        dfs(1, 0);
        for (int i = 1; i <= n; i++) {
            System.out.println(Ans[i]);
        }
    }
}
