#include <stdio.h>
 
int min(int a, int b) {
    return a < b ? a : b;
}
int main() {
    int a, b, c, d;
    scanf("%d%d%d%d", &a, &b, &c, &d);
    a *= 2, b *= 2, c *= 2, d *= 2;
    int tmp[3] = {a, b * 2 - d, c * 2 - d};
    int R = -1;
    for (int i = 0; i < 3; i++) {
        if (tmp[i] < a) {
            continue;
        }
        int l = c - tmp[i], r = min(b - tmp[i], (d - tmp[i]) / 2);
        if (l <= r && r > R) {
            R = r;
        }
    }
    printf("%.2lf\n", R / 2.0);
    return 0;
}
