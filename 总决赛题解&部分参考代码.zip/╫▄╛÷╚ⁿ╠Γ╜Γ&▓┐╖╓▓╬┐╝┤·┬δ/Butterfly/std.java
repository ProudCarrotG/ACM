import java.util.*;
public class std2 {
    public static void main(String[] argv) {
        Scanner sc = new Scanner(System.in);
        int a = sc.nextInt(), b = sc.nextInt(), c = sc.nextInt(), d = sc.nextInt();
        a *= 2; b *= 2; c *= 2; d *= 2;
        int[] tmp = new int[]{a, b * 2 - d, c * 2 - d};
        int R = -1;
        for (int i = 0; i < 3; i++) {
            if (tmp[i] < a) {
                continue;
            }
            int l = c - tmp[i], r = Math.min(b - tmp[i], (d - tmp[i]) / 2);
            if (l <= r && r > R) {
                R = r;
            }
        }
        if (R % 2 == 0) {
            System.out.println(R / 2 + ".00");
        } else {
            System.out.println(R / 2 + ".50");
        }
    }
}
