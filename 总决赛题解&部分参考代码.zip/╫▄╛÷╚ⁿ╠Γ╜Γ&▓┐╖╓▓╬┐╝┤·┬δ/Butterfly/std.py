a, b, c, d = tuple(map(int, input().split()))
a *= 2
b *= 2
c *= 2
d *= 2
tmp = [a, b * 2 - d, c * 2 - d]
R = -1
for x in tmp:
    if x < a:
        continue
    l = c - x
    r = min(b - x, (d - x) // 2)
    if l <= r:
        R = max(R, r)
if R % 2 == 0:
    print(R // 2, end = ".00")
else:
    print(R // 2, end = ".50")
