#include <bits/stdc++.h>

using namespace std;

#define N 1000006

int n,cnt=0;
int a[N],sum[N],sum2[N];
long long Ans[N];
vector<int >edge[N];

void dfs(int x,int Fa){
    int mx=0,mmx=0;
    for(int i=0;i<edge[x].size();i++){
        int y=edge[x][i];
        if(y==Fa)continue;
        dfs(y,x);
        if(sum[y]>mx){
            mmx=mx;
            mx=sum[y];
        }
        else if(sum[y]>mmx){
            mmx=sum[y];
        }
    }
    sum[x]=mx+a[x];
    sum2[x]=mmx+a[x];
}
void dfs2(int x,int Fa){
    int cnt=0,mx=0,mmx=0;
    if(sum[x]==sum[Fa]-a[Fa]){
        mx=sum2[Fa];
    }
    else mx=sum[Fa];
    for(int i=0;i<edge[x].size();i++){
        int y=edge[x][i];
        if(y==Fa)continue;
        if(sum[y]>mx){
            mmx=mx;
            mx=sum[y];
        }
        else if(sum[y]>mmx){
            mmx=sum[y];
        }
        dfs2(y,x);
    }
    Ans[x]=1ll*mx*1ll*mmx;
}
int main(){
    //freopen("20.in","r",stdin);
    //freopen("20.out","w",stdout);
    scanf("%d",&n);
    for(int i=1;i<=n;i++)scanf("%d",&a[i]);
    for(int i=1;i<n;i++){
        int x,y;
        scanf("%d%d",&x,&y);
        edge[x].push_back(y);
        edge[y].push_back(x);
    }
    dfs(1,0);
    dfs2(1,0);
    for(int i=1;i<=n;i++)printf("%lld\n",Ans[i]);
}
