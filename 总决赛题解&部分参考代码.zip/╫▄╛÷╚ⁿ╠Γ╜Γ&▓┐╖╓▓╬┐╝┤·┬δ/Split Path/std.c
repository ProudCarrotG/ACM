#include <stdio.h>

#define N 1000006

int n,cnt=0,l=0;
int a[N],sum[N],sum2[N],to[N<<1],h[N<<1],s[N];
long long Ans[N];

void add(int x,int y){
	to[++l]=y,h[l]=s[x],s[x]=l;
	to[++l]=x,h[l]=s[y],s[y]=l;
}
void dfs(int x,int Fa){
    int mx=0,mmx=0,i;
    for(i=s[x];i;i=h[i]){
       int y=to[i];
        if(y==Fa)continue;
        dfs(y,x);
        if(sum[y]>mx){
            mmx=mx;
            mx=sum[y];
        }
        else if(sum[y]>mmx){
            mmx=sum[y];
        }
    }
    sum[x]=mx+a[x];
    sum2[x]=mmx+a[x];
}
void dfs2(int x,int Fa){
    int cnt=0,mx=0,mmx=0,i;
    if(sum[x]==sum[Fa]-a[Fa]){
        mx=sum2[Fa];
    }
    else mx=sum[Fa];
    for(i=s[x];i;i=h[i]){
       	int y=to[i];
        if(y==Fa)continue;
        if(sum[y]>mx){
            mmx=mx;
            mx=sum[y];
        }
        else if(sum[y]>mmx){
            mmx=sum[y];
        }
        dfs2(y,x);
    }
    Ans[x]=1ll*mx*1ll*mmx;
}
int main(){
    scanf("%d",&n);
    int i; 
    for(i=1;i<=n;i++)scanf("%d",&a[i]);
    for(i=1;i<n;i++){
        int x,y;
        scanf("%d%d",&x,&y);
        add(x,y);
    }
    dfs(1,0);
    dfs2(1,0);
    for(i=1;i<=n;i++)printf("%lld\n",Ans[i]);
}


