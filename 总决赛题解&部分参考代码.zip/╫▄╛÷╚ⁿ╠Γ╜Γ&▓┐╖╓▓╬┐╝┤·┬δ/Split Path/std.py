N = 1000006

n = 0
cnt = 0
a = [0] * N
sum = [0] * N
sum2 = [0] * N
Ans = [0] * N
edge = [[] for _ in range(N)]

def dfs(x, Fa):
    global sum, sum2
    mx = 0
    mmx = 0
    for i in range(len(edge[x])):
        y = edge[x][i]
        if y == Fa:
            continue
        dfs(y, x)
        if sum[y] > mx:
            mmx = mx
            mx = sum[y]
        elif sum[y] > mmx:
            mmx = sum[y]
    sum[x] = mx + a[x]
    sum2[x] = mmx + a[x]

def dfs2(x, Fa):
    global Ans
    cnt = 0
    mx = 0
    mmx = 0
    if sum[x] == sum[Fa] - a[Fa]:
        mx = sum2[Fa]
    else:
        mx = sum[Fa]
    for i in range(len(edge[x])):
        y = edge[x][i]
        if y == Fa:
            continue
        if sum[y] > mx:
            mmx = mx
            mx = sum[y]
        elif sum[y] > mmx:
            mmx = sum[y]
        dfs2(y, x)
    Ans[x] = mx * mmx

# 主函数
if __name__ == '__main__':
    n = int(input())
    a = list(map(int, input().split()))
    for _ in range(n - 1):
        x, y = map(int, input().split())
        edge[x].append(y)
        edge[y].append(x)
    dfs(1, 0)
    dfs2(1, 0)
    for i in range(1, n+1):
        print(Ans[i])
