import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    static final int N = 1000006;
    static int n, cnt;
    static int[] a = new int[N];
    static int[] sum = new int[N];
    static int[] sum2 = new int[N];
    static long[] Ans = new long[N];
    static ArrayList<Integer>[] edge = new ArrayList[N];

    public static void dfs(int x, int Fa) {
        int mx = 0, mmx = 0;
        for (int i = 0; i < edge[x].size(); i++) {
            int y = edge[x].get(i);
            if (y == Fa)
                continue;
            dfs(y, x);
            if (sum[y] > mx) {
                mmx = mx;
                mx = sum[y];
            } else if (sum[y] > mmx) {
                mmx = sum[y];
            }
        }
        sum[x] = mx + a[x];
        sum2[x] = mmx + a[x];
    }

    public static void dfs2(int x, int Fa) {
        int cnt = 0, mx = 0, mmx = 0;
        if (sum[x] == sum[Fa] - a[Fa]) {
            mx = sum2[Fa];
        } else {
            mx = sum[Fa];
        }
        for (int i = 0; i < edge[x].size(); i++) {
            int y = edge[x].get(i);
            if (y == Fa)
                continue;
            if (sum[y] > mx) {
                mmx = mx;
                mx = sum[y];
            } else if (sum[y] > mmx) {
                mmx = sum[y];
            }
            dfs2(y, x);
        }
        Ans[x] = 1L * mx * 1L * mmx;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        n = sc.nextInt();
        for (int i = 1; i <= n; i++) {
            a[i] = sc.nextInt();
        }
        for (int i = 1; i < n; i++) {
            int x = sc.nextInt();
            int y = sc.nextInt();
            if (edge[x] == null) {
                edge[x] = new ArrayList<>();
            }
            edge[x].add(y);
            if (edge[y] == null) {
                edge[y] = new ArrayList<>();
            }
            edge[y].add(x);
        }
        dfs(1, 0);
        dfs2(1, 0);
        for (int i = 1; i <= n; i++) {
            System.out.println(Ans[i]);
        }
    }
}
