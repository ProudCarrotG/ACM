import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

class Main {
    static final int maxn = 2000005;

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int n = scanner.nextInt();

        int[] h = new int[maxn];
        int[] a = new int[maxn];

        for (int i = 1; i <= n; i++) {
            int x = scanner.nextInt();
            h[x]++;
            a[i] = x;
        }

        quickSort(a, 1, n);

        for (int i = 1; i < maxn; i++) {
            h[i] += h[i - 1];
        }

        long ans = 0;

        for (int i = 1; i <= a[n]; i++) {
            int ok = 1;
            List<P> g = new ArrayList<>();

            for (int j = 1; j <= a[n] && j * i <= a[n]; j++) {
                int x = h[i * j + i - 1] - h[i * j - 1];

                if ((x & 1) == 1) {
                    g.add(new P(j, x));
                }
            }

            if (g.size() > 2) {
                ok = 0;
            } else if (g.size() == 1) {
                if (g.get(0).first == 1) {
                    ans += g.get(0).second;
                }
            } else if (g.size() == 2) {
                int x = g.get(1).first;
                int y = g.get(0).first;

                if (y + 1 == x) {
                    ans += g.get(1).second;
                }
            }
        }

        System.out.println(ans);
    }

    static void quickSort(int[] arr, int left, int right) {
        if (left < right) {
            int pivot = partition(arr, left, right);

            quickSort(arr, left, pivot - 1);
            quickSort(arr, pivot + 1, right);
        }
    }

    static int partition(int[] arr, int left, int right) {
        int pivot = arr[right];
        int i = left - 1;

        for (int j = left; j < right; j++) {
            if (arr[j] < pivot) {
                i++;

                int temp = arr[i];
                arr[i] = arr[j];
                arr[j] = temp;
            }
        }

        int temp = arr[i + 1];
        arr[i + 1] = arr[right];
        arr[right] = temp;

        return i + 1;
    }

    static class P {
        int first;
        int second;

        public P(int first, int second) {
            this.first = first;
            this.second = second;
        }
    }
}
