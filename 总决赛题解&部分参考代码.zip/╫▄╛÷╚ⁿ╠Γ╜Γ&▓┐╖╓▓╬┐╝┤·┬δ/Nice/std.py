import sys

def lowbit(x):
    return x & (-x)

def main():
    maxn = 2e6 + 5
    h = [0] * maxn
    a = [0] * maxn
    g = []

    n = int(input())

    for i in range(1, n+1):
        x = int(input())
        h[x] += 1
        a[i] = x

    a.sort()

    for i in range(1, maxn):
        h[i] += h[i-1]

    ans = 0

    for i in range(1, a[n]+1):
        ok = 1
        g.clear()

        for j in range(1, a[n]+1):
            if j * i > a[n]:
                break

            x = h[i*j+i-1] - h[i*j-1]
            if x & 1:
                g.append((j, x))

        if len(g) > 2:
            ok = 0
        elif len(g) == 1:
            if g[0][0] == 1:
                ans += g[0][1]
        elif len(g) == 2:
            x = g[1][0]
            y = g[0][0]
            if y + 1 == x:
                ans += g[1][1]

    print(ans)

if __name__ == "__main__":
    main()
