#include<bits/stdc++.h>
#define ll long long
#define pb push_back
#define lowbit(x) ((x)&(-(x)))
#define mid ((l+r)>>1)
#define lson rt<<1, l, mid
#define rson rt<<1|1, mid+1, r
#define fors(i, a, b) for(int i = (a); i < (b); ++i)
using namespace std;
const int maxn = 2e6 + 5;
int h[maxn], a[maxn];
#define P pair<int,int>
vector<P> g;
int main()
{
    //freopen("1.in","r",stdin);
    //freopen("1.out","w",stdout);
    int n; cin>>n;
    fors(i,1,n+1){
        int x; scanf("%d", &x); h[x]++; a[i] = x;
    }
    sort(a+1,a+n+1);
    fors(i,1,maxn) h[i] += h[i-1];
    ll ans = 0;
    fors(i,1,a[n]+1){
        int ok = 1;
        g.clear();
        for(int j = 1; j <= a[n] && j * i <= a[n]; j ++){
            int x = h[i*j+i-1] - h[i*j-1];
            if(x&1) g.pb(P(j, x));
        }
        if(g.size() > 2) ok = 0;
        else if(g.size() == 1){
            if(g[0].first == 1){
                ans += g[0].second;
            }
        }else if(g.size() == 2){
            int x = g[1].first, y = g[0].first;
            if(y+1 == x){
                ans += g[1].second;
            }
        }
    }
    cout<<ans<<endl;
	return 0;

}
