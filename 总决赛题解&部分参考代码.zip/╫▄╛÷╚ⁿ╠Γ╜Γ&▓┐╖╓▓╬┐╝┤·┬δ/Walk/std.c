#include <stdio.h>
#include <stdlib.h>
#define N 200100
#define mod 998244353
#define L (1<<18|2)

int head[N],nxt[N*2],to[N*2],n;

int qpow(int x,int y) {
	int ans=1;
	while (y) {
		if (y&1) ans=1LL*ans*x%mod;
		x=1LL*x*x%mod;y>>=1;
	}
	return ans;
}

int val[N],id[N];
int up[N],down[N],suf[N];

int W[L*2],*w0[20],*w1[20];
void init(int n) {
	int *cur=W,G,i;
	for (int len=1,t=0;len<=n*2;len<<=1,t++) {
		G=qpow(3,(mod-1)/(len<<1));
		w0[t]=cur;
		for (i=cur[0]=1;i<len;i++)
			cur[i]=1LL*cur[i-1]*G%mod;
		cur+=len;
		G=qpow(G,mod-2);
		w1[t]=cur;
		for (i=cur[0]=1;i<len;i++)
			cur[i]=1LL*cur[i-1]*G%mod;
		cur+=len;
	}
}
int R[L],A[L],B[L];
void DFT(int *a,int n,int f) {
	int i,o,k,t,x,y,*wn,*w;
	for (t=0;(1<<(t+1))<n;t++);
	for (i=0;i<n;i++) R[i]=R[i>>1]>>1|(i&1)<<t;
	for (i=0;i<n;i++) if (R[i]>i) o=a[i],a[i]=a[R[i]],a[R[i]]=o;
	for (i=1,t=0;i<n;i<<=1,t++)
		for (o=0,wn=f==1?w0[t]:w1[t];o<n;o+=i<<1)
			for (k=0,w=wn;k<i;k++,w++) {
				x=a[o+k],y=1LL*a[o+k+i]**w%mod;
				a[o+k]=(x+y)%mod;
				a[o+k+i]=(x-y)%mod;
			}
}
void mul(int *a,int n,int *b,int m,int *c) {
	int len,i;
	for (len=1;len<n+m-1;len<<=1);
	for (i=0;i<n;i++) A[i]=a[i];
	for (;i<len;i++) A[i]=0;
	for (i=0;i<m;i++) B[i]=b[i];
	for (;i<len;i++) B[i]=0;
	DFT(A,len,1);
	DFT(B,len,1);
	for (i=0;i<len;i++) c[i]=1LL*A[i]*B[i]%mod;
	DFT(c,len,-1);
	len=qpow(len,mod-2);
	for (i=0;i<n+m-1;i++) c[i]=1LL*c[i]*len%mod;
}
int poly[L*20],*p[L*2],top[N*2],*cur;
int g[L*2],tmp[L];
void devide(int k,int l,int r) {
	if (l==r) top[k]=2,p[k]=cur,cur[0]=1,cur[1]=val[l],cur+=2;
	else {
		int mid=(l+r)>>1;
		devide(k*2,l,mid);
		devide(k*2|1,mid+1,r);
		p[k]=cur;
		mul(p[k*2],top[k*2],p[k*2|1],top[k*2|1],p[k]);
		top[k]=r-l+2;
		cur+=top[k];
	}
}
void reverse(int *l,int *r) {
	if (l==r) return;
	r--;
	if (l==r) return;
	int o;
	o=*l;*l=*r,*r=o;
	l++;
	reverse(l,r);
}
void solve(int k,int l,int r) {
	if (l==r) down[id[l]]=cur[0];
	else {
		int mid=(l+r)>>1;
		reverse(p[k*2],p[k*2]+top[k*2]);
		reverse(p[k*2|1],p[k*2|1]+top[k*2|1]);
		mul(cur,top[k],p[k*2|1],top[k*2|1],tmp);
		cur+=top[k];
		for (int i=0;i<top[k*2];i++)
			cur[i]=(tmp+top[k*2|1]-1)[i];
		solve(k*2,l,mid);
		mul(cur-top[k],top[k],p[k*2],top[k*2],tmp);
		for (int i=0;i<top[k*2|1];i++)
			cur[i]=(tmp+top[k*2]-1)[i];
		solve(k*2|1,mid+1,r);
		cur-=top[k];
	}
}
int work(int n) {
	cur=poly;
	devide(1,0,n-1);
	int all=0;
	for (int i=0,pi=1;i<=n;pi=1LL*pi*++i%mod) {
		g[i]=pi;
		all=(all+1LL*pi*p[1][i])%mod;
	}
	cur=g;
	solve(1,0,n-1);
	return all;
}

void dfs1(int k,int fa) {
	int m=0;
	for (int i=head[k];i;i=nxt[i])
		if (to[i]!=fa)
			dfs1(to[i],k);
	for (int i=head[k];i;i=nxt[i])
		if (to[i]!=fa)
			id[m]=to[i],val[m++]=up[to[i]];
	up[k]=m?work(m):1;
}
void dfs2(int k,int fa) {
	for (int i=head[k];i;i=nxt[i])
		if (to[i]!=fa)
			down[to[i]]=1LL*down[to[i]]*down[k]%mod,dfs2(to[i],k);
}

int main()
{
	int i,a,b,tot=0;
	scanf("%d",&n);
	for (i=1;i<n;i++) {
		scanf("%d%d",&a,&b);
		to[++tot]=b,nxt[tot]=head[a],head[a]=tot;
		to[++tot]=a,nxt[tot]=head[b],head[b]=tot;
	}
	init(n-1);
	dfs1(1,0);
	down[1]=1;
	dfs2(1,0);
	for (i=1;i<=n;i++) {
		a=(1LL*down[i]*up[i]%mod+mod)%mod;
		printf("%d\n",a);
	}
	return 0;
}
