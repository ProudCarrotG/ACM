import java.util.Arrays;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int m = scanner.nextInt();
        int n = scanner.nextInt();
        if (n == 1) {
            System.out.println(m - 1);
            return;
        }
        int[] a = new int[2 * n + 1];
        for (int i = 1; i <= n; ++i) {
            a[i] = scanner.nextInt();
            a[i + n] = a[i] + m;
        }
        Arrays.sort(a, 1, 2 * n + 1);
        int l = 0;
        int r = 0;
        int ans = 0;
        int[] p = new int[n + 1];
        int[] f = new int[n + 1];
        for (int i = 1; i <= n; ++i) {
            r = Math.max(r, a[i + 1] - a[i] - 1);
        }
        for (int i = 1; i <= n; ++i) {
            if (a[i + 1] - a[i] - 1 == r) {
                for (int j = 1; j <= n; ++j) {
                    p[j] = a[i + j];
                }
                for (int j = n; j >= 1; --j) {
                    p[j] -= p[1];
                }
                break;
            }
        }
        while (l <= r) {
            int mid = (l + r) >> 1;
            if (check(mid, m, n, p, f)) {
                ans = mid;
                r = mid - 1;
            } else {
                l = mid + 1;
            }
        }
        System.out.println(ans);
    }

    public static boolean check(int x, int m, int n, int[] p, int[] f) {
        f[1] = 0;
        for (int i = 2; i <= n; i++) {
            f[i] = f[i - 1];
            if (f[i - 1] >= p[i] - 1) {
                f[i] = p[i] + x;
            }
            if (f[i - 1] >= p[i] - x - 1) {
                f[i] = Math.max(f[i], p[i]);
            }
            if (i != 2 && f[i - 2] >= p[i] - x - 1) {
                f[i] = Math.max(f[i], p[i - 1] + x);
            }
        }
        if (f[n] >= Math.min(m - 1, m + p[1] - x - 1)) {
            return true;
        }
        f[2] = Math.max(x, p[2]);
        for (int i = 3; i <= n; i++) {
            f[i] = f[i - 1];
            if (f[i - 1] >= p[i] - 1) {
                f[i] = p[i] + x;
            }
            if (f[i - 1] >= p[i] - x - 1) {
                f[i] = Math.max(f[i], p[i]);
            }
            if (i != 3 && f[i - 2] >= p[i] - x - 1) {
                f[i] = Math.max(f[i], p[i - 1] + x);
            }
        }
        return f[n] >= Math.min(m - 1, m + p[2] - x - 1);
    }
}
