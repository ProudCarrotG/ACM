#include <stdio.h>
#include <stdlib.h>

#define MAX(x, y) (((x) > (y)) ? (x) : (y))
#define MIN(x, y) (((x) < (y)) ? (x) : (y))

#define N 200005

int n, m, l, r, ans;
int a[N], p[N], f[N];

int cmp ( const void *a , const void *b )
{

  return *(int *)a - *(int *)b; 
}
void init(){
	for (int i=1;i<=n;++i) r=MAX(r,a[i+1]-a[i]-1);
	for (int i=1;i<=n;++i)
		if (a[i+1]-a[i]-1==r){
			for (int j=1;j<=n;++j) p[j]=a[i+j];
			for (int j=n;j;--j) p[j]-=p[1];
			break;
		}
}
int check(int x){
	f[1]=0;
	for (int i=2;i<=n;i++){
		f[i]=f[i-1];
		if (f[i-1]>=p[i]-1) f[i]=p[i]+x;
		if (f[i-1]>=p[i]-x-1) f[i]=MAX(f[i],p[i]);
		if (i!=2 && f[i-2]>=p[i]-x-1) f[i]=MAX(f[i],p[i-1]+x);
	}
	if (f[n]>=MIN(m-1,m+p[1]-x-1)) return 1;
	
	f[2]=MAX(x,p[2]);
	for(int i=3;i<=n;i++){
		f[i]=f[i-1];
		if(f[i-1]>=p[i]-1) f[i]=p[i]+x;
		if(f[i-1]>=p[i]-x-1) f[i]=MAX(f[i],p[i]);
		if(i!=3 && f[i-2]>=p[i]-x-1) f[i]=MAX(f[i],p[i-1]+x);
	}
	if(f[n]>=MIN(m-1,m+p[2]-x-1)) return 1;
	return 0;
}
int main() {
    scanf("%d%d", &m, &n);
    if (n == 1) {
        printf("%d\n", m - 1);
        return 0;
    }
    for (int i = 1; i <= n; ++i) {
        scanf("%d", &a[i]);
        a[i + n] = a[i] + m;
    }
    qsort(a + 1, (n << 1), sizeof(int), cmp);
    // for(int i = 1;i <= 2*n;i ++){
    //     printf("%d ",a[i]);
    // }
    init();
    while (l <= r) {
        int mid = (l + r) >> 1;
        if (check(mid)) {
            ans = mid;
            r = mid - 1;
        } else {
            l = mid + 1;
        }
    }
    printf("%d\n", ans);
    return 0;
}
