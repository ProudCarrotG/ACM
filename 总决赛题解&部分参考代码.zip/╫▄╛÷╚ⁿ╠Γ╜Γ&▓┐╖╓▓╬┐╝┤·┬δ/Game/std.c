#include <stdio.h>
#include <stdlib.h>

#define LL long long
#define N 300010
#define min(x, y) ((x) < (y) ? (x) : (y))
int n;
LL pos[N],x[N];
int in[N],low[N];
int d[N];
LL f[N];
int pre[N];

int cmp(const void * a, const void * b)
{
    if( *(long long int*)a - *(long long int*)b < 0 )
        return -1;
    if( *(long long int*)a - *(long long int*)b > 0 )
        return 1;
    return 0;
}
int F(int l,int r,LL w) {
	if (l==r) return l;
	int mid=(l+r)>>1;
	return w<=x[mid]?F(l,mid,w):F(mid+1,r,w);
}
LL work() {
	int i,m;LL mi,ans;
	for (i=1;i<=n;i++) x[i]=pos[i];
	
	qsort(x+1,n,sizeof(x[0]),cmp);
	for (i=2,m=1;i<=n;i++) if (x[i]!=x[m]) x[++m]=x[i];
	for (i=1;i<=m;i++) d[i]=0;

	for (i=1;i<=n;i++) {
		in[i]=F(1,m,pos[i]);
		low[i]=in[i];
	}
	for (i=1;i<=n;i++) if (pre[i]) low[pre[i]]=min(low[pre[i]],in[i]);
	for (i=1;i<=n;i++) if (low[i]<in[i]) ++d[low[i]],--d[in[i]];

	for (i=1;i<=m;i++) d[i]+=d[i-1];
	for (i=m-1,f[m]=0,mi=x[m]*3;i;i--) {
		f[i]=d[i]?mi-x[i]*3:f[i+1]+x[i+1]-x[i];
		f[i]=min(f[i],(x[m]-x[i])*2);
		mi=min(mi,f[i]+x[i]*3);
	}
	for (i=2,ans=f[1];i<=m;i++)
		ans=min(ans,f[i]+(x[i]-x[1])*2);
	return ans;
}
int main()
{
	int i;LL a,b;
	scanf("%d",&n);
	for (i=1;i<=n;i++) {
		scanf("%lld%d",pos+i,pre+i);
		if (pre[i]==1) pre[i]=0; else scanf("%d",pre+i);
	}
	a=work();
	for (i=1;i<=n;i++) pos[i]*=-1;
	b=work();

	printf("%lld",min(a,b));
	return 0;
}
