#include<bits/stdc++.h>

#define LL long long
#define N 300010
#define min(x, y) ((x) < (y) ? (x) : (y))
int n;
LL pos[N],x[N];
int in[N],low[N];
int d[N];
LL f[N];
int pre[N];

LL work() {
	int i,m;LL mi,ans;
	for (i=1;i<=n;i++) x[i]=pos[i];
	
	std::sort(x+1,x+1+n);m=std::unique(x+1,x+1+n)-x-1;
	for (i=1;i<=m;i++) d[i]=0;

	for (i=1;i<=n;i++) {
		in[i]=std::lower_bound(x+1,x+1+m,pos[i])-x;
		low[i]=in[i];
	}
	for (i=1;i<=n;i++) if (pre[i]) low[pre[i]]=min(low[pre[i]],in[i]);
	for (i=1;i<=n;i++) if (low[i]<in[i]) ++d[low[i]],--d[in[i]];

	for (i=1;i<=m;i++) d[i]+=d[i-1];
	//for (i=1;i<=m;i++) printf("%lld%c",x[i]," \n"[i==m]);
	//for (i=1;i<=m;i++) printf("%d%c",d[i]," \n"[i==m]);
	for (i=m-1,f[m]=0,mi=x[m]*3;i;i--) {
		f[i]=d[i]?mi-x[i]*3:f[i+1]+x[i+1]-x[i];
		f[i]=min(f[i],(x[m]-x[i])*2);
		mi=min(mi,f[i]+x[i]*3);
	}
	for (i=2,ans=f[1];i<=m;i++)
		ans=min(ans,f[i]+(x[i]-x[1])*2);
	return ans;
}
int main()
{
	int i;LL a,b;
	scanf("%d",&n);
	for (i=1;i<=n;i++) {
		scanf("%lld%d",pos+i,pre+i);
		if (pre[i]==1) pre[i]=0; else scanf("%d",pre+i);
	}
	a=work();
	for (i=1;i<=n;i++) pos[i]*=-1;
	b=work();

	printf("%lld",min(a,b));
	return 0;
}
