
def work() :
    x = []
    for i in range(n) :
        x.append(pos[i])

    def F(l,r,w) :
        if l==r :
            return l
        mid=(l+r)>>1
        if w<=x[mid] :
            return F(l,mid,w)
        else :
            return F(mid+1,r,w)

    x.sort()
    m = 1
    for i in range(1,n) :
        if x[i] != x[i-1] :
            x[m] = x[i]
            m += 1
    d = [0]*m
    in_ = [0]*n
    low = [0]*n
    for i in range(n) :
        in_[i]=F(0,m-1,pos[i])
        low[i]=in_[i]

    for i in range(n) :
        if pre[i]>0 :
            low[pre[i]-1]=min(low[pre[i]-1],in_[i])
    for i in range(n) :
        if low[i]<in_[i] :
            d[low[i]]+=1
            d[in_[i]]-=1

    for i in range(1,m) :
        d[i]+=d[i-1]

    f = [0]*m
    f[m-1]=0
    mi=x[m-1]*3
    for i in range(m-2,-1,-1) :
        if d[i] !=0 :
            f[i] = mi-x[i]*3
        else :
            f[i] = f[i+1]+x[i+1]-x[i]
            
        f[i]=min(f[i],(x[m-1]-x[i])*2)
        mi=min(mi,f[i]+x[i]*3)

    ans = f[0]
    for i in range(1,m) :
        ans=min(ans,f[i]+(x[i]-x[0])*2)
    return ans

n = int(input())
pos = [0]*n
pre = [0]*n
for i in range(n) :
    G = list(map(int,input().split()))
    pos[i] = G[0]
    if G[1] == 2 :
        pre[i] = G[2]
        
a=work()
for i in range(n) :
    pos[i]*=-1
b=work()

print(min(a,b))
