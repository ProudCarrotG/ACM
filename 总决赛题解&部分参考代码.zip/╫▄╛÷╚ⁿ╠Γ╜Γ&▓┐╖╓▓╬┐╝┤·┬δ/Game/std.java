
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.Scanner;
import java.util.Arrays;

public class Main{
	public static long work(int n,long[] pos,int[] pre) {
		int i,m,l,r,mid;
		long mi,ans;
		long[] x = new long[n];
		for (i=0;i<n;i++) x[i]=pos[i];
		
		Arrays.sort(x,0,n);
		for (i=1,m=1;i<n;i++)
			 if (x[i]!=x[i-1])
			 	x[m++]=x[i];
		int[] d = new int[m];
		int[] in = new int[n];
		int[] low = new int[n];
		for (i=0;i<m;i++) d[i]=0;

		for (i=0;i<n;i++) {
			l=0;r=m-1;
			while (l!=r) {
				mid=(l+r)>>1;
				if (pos[i]<=x[mid]) r=mid;
				else l=mid+1;
			}
			in[i]=l;
			low[i]=in[i];
		}
		for (i=0;i<n;i++) if (pre[i]>0) low[pre[i]-1]=Math.min(low[pre[i]-1],in[i]);
		for (i=0;i<n;i++) if (low[i]<in[i]) {
			++d[low[i]];
			--d[in[i]];
		} 

		for (i=1;i<m;i++) d[i]+=d[i-1];
		long[] f= new long[n];
		f[m-1]=0;
		mi=x[m-1]*3;
		for (i=m-2;i>=0;i--) {
			if (d[i]!=0)
				f[i]=mi-x[i]*3;
			else
				f[i]=f[i+1]+x[i+1]-x[i];
			f[i]=Math.min(f[i],(x[m-1]-x[i])*2);
			mi=Math.min(mi,f[i]+x[i]*3);
		}
		for (i=1,ans=f[0];i<m;i++)
			ans=Math.min(ans,f[i]+(x[i]-x[0])*2);
		return ans;
	}
	public static void main(String[] args)
	{
        Scanner scanner = new Scanner(System.in);
		int i;long a,b;
		int n=scanner.nextInt();
		long[] pos = new long[n];
		int[] pre = new int[n];
		for (i=0;i<n;i++) {
			pos[i]=scanner.nextLong();
			pre[i]=scanner.nextInt();
			if (pre[i]==1) pre[i]=0; else pre[i]=scanner.nextInt();
		}
		a=work(n,pos,pre);
		for(i=0;i<n;i++) pos[i]*=-1;
		b=work(n,pos,pre);

		System.out.println(Math.min(a,b));
	}
}